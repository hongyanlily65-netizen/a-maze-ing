_This project has been created as part of the 42 curriculum by dmena-li, rmarin-n._

# A-Maze-ing

## Description

A-Maze-ing generates a maze from a configuration file, writes the mandatory
hexadecimal representation to a file, and renders the result in the terminal.
The implementation intentionally stays small: randomized Prim is the only
generation algorithm and breadth-first search (BFS) is the only solver.

## Instructions

Python 3.10 or later is required.

```bash
make install
make run
```

The equivalent direct command is:

```bash
python3 a_maze_ing.py config.txt
```

The interactive menu contains four options:

1. New maze
2. Show/Hide path
3. Change colour
4. Exit

Useful Makefile rules are `install`, `run`, `debug`, `lint`, `build`, and
`clean`.

## Configuration

The six mandatory keys and the optional seed are:

```text
WIDTH=15
HEIGHT=15
ENTRY=0,0
EXIT=14,14
OUTPUT_FILE=maze.txt
PERFECT=True
SEED=42
```

Coordinates use the `x,y` format. Comments start with `#`. When `PERFECT=True`,
Prim creates exactly one path between navigable cells. When it is `False`, one
extra wall is removed to create a loop. A seed reproduces the same maze.

## Technical Choices

Each cell is one hexadecimal digit. Its bits represent North (`1`), East (`2`),
South (`4`), and West (`8`) walls. A set bit means that the wall is closed.

Randomized Prim was chosen because it naturally creates a connected perfect
maze and is simple to explain. The required `42` is represented by fully closed
cells that Prim avoids. Small mazes print a warning and omit the pattern.

BFS was chosen because it always returns the shortest path in an unweighted
maze. The output path is converted to `N`, `E`, `S`, and `W`.

## Structure

```text
a_maze_ing.py
src/
  config.py
  mazegen/
    maze_generator.py
    prim.py
    pattern42.py
    solve.py
  render/render.py
  output/output.py
```

`MazeGenerator` is reusable without the renderer or main program:

```python
from mazegen import MazeGenerator, solve_shortest

maze = MazeGenerator(15, 15, (0, 0), (14, 14), seed=42)
grid = maze.generate()
path = solve_shortest(maze)
```

Build the reusable `mazegen` package with:

```bash
make install
make build
```

This creates `mazegen-1.0.0.tar.gz` in the repository root. Only the
`src/mazegen/` package is included; rendering, configuration, and output
remain application code.

## Output Format

The output contains one hexadecimal row per maze row, an empty line, then the
entry coordinate, exit coordinate, and shortest path. Every line ends in `\n`.

## Resources

- Python documentation: `random`, `enum`, `collections.deque`
- Wikipedia: maze generation algorithms and Prim's algorithm
- AI was used to review requirements, simplify module boundaries, and assist
  with validation of the configuration, wall consistency, and output format.

## Team and Project Management

- dmena-li: generator, solver, and rendering.
- rmarin-n: architecture, configuration, main program, and documentation.

The work was divided by module so generation, solving, rendering, and output
could be tested independently. Keeping one generator and one solver made the
final design easier to understand and maintain.
